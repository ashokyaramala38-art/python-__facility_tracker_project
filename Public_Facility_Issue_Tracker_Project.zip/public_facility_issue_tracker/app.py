
"""Public Facility Issue Tracker — launcher."""
from issue_tracker.cli import run_cli
from issue_tracker.gui import run_gui

def main():
    print("\n  PUBLIC FACILITY ISSUE TRACKER")
    print("  1. Open graphical interface")
    print("  2. Open terminal interface")
    print("  0. Exit")
    while True:
        choice = input("\nChoose an option: ").strip()
        if choice == "1":
            run_gui()
            return
        if choice == "2":
            run_cli()
            return
        if choice == "0":
            print("Goodbye.")
            return
        print("Please enter 1, 2, or 0.")

if __name__ == "__main__":
    main()
