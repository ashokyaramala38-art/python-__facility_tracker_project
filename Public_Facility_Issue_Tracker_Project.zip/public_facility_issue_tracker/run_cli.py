from issue_tracker.cli import run_cli
if __name__ == "__main__": run_cli()
