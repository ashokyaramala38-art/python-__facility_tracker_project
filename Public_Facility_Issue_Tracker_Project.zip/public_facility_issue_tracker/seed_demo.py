from pathlib import Path
import json
from issue_tracker.storage import Storage
from issue_tracker.service import IssueService
ROOT=Path(__file__).resolve().parent
src=ROOT/"data"/"sample_issues.json"
rows=json.loads(src.read_text(encoding="utf-8"))
from issue_tracker.models import Issue
service=IssueService(Storage(ROOT/"data"))
service.issues=[Issue.from_dict(row) for row in rows]
service.storage.save(service.issues)
print(f"Loaded {len(rows)} demo issues into data/issues.json and data/issues.csv")
