
# FacilityCare — Public Facility Issue Tracker

A polished, beginner-friendly Python application for recording, tracking, searching and reporting public-facility issues. Built to the supplied **Everyday Innovators — Project #77** brief.

## Features mapped to the brief

| Requirement | Implementation |
|---|---|
| Interactive terminal interface | Menu-driven CLI (`python app.py`, choose 2) |
| Defensive input validation | Required fields, length limits, controlled choices, ISO date checks, due-date boundary check |
| Core business logic | Create issues, update status, search/filter, overdue detection |
| Local persistence | Automatic JSON + CSV writes in `data/` |
| Query & search | Keyword, category and status filters in GUI; keyword search in CLI |
| Executive summary | Totals, status counts, resolution rate, average age, category/priority breakdown |
| Multi-format exports | Timestamped Markdown summary, plain-text audit log, CSV snapshot |
| Threshold warnings | Overdue issue detection and visual highlighting |
| GUI enhancement | Tkinter desktop interface with dashboard, issue register and report tools |
| Bulk import | CSV import with schema checks and row-by-row errors |
| Sample dataset | 40 sample records supplied in JSON and CSV |

## Requirements

- Python 3.10 or newer
- No third-party packages required
- Tkinter is included with most standard Python installations (some Linux distributions package it separately).

## Run the application

1. Extract the ZIP file.
2. Open a terminal in the extracted `public_facility_issue_tracker` folder.
3. Run:

```bash
python app.py
```

Choose **1** for the graphical interface or **2** for the terminal interface.

You can also launch the GUI directly:

```bash
python run_gui.py
```

Or the CLI directly:

```bash
python run_cli.py
```

## Data and reports

- `data/issues.json` — primary structured store
- `data/issues.csv` — automatically maintained CSV mirror
- `data/sample_issues.json` and `data/sample_issues.csv` — 40 demo records
- `reports/` — generated exports

The app creates an empty live store if none exists. To demo with the supplied sample data, copy `data/sample_issues.json` over `data/issues.json` before first launch, or run `python seed_demo.py`.

## Importing legacy data

Use **Reports & tools → Import legacy CSV** in the GUI, or option 6 in the CLI. The CSV must contain the columns used by the application. Invalid rows are skipped and reported with their source row number. Existing IDs are not imported twice.

## Tests

Run the automated tests from the project folder:

```bash
python -m unittest discover -s tests -v
```

The tests cover persistence, validation, status updates, searching and overdue detection.

## Suggested hackathon demo (3–4 minutes)

1. Launch the application and show the branded dashboard.
2. Open **Issue register → Report issue** and submit a valid report.
3. Try leaving a required field blank or entering a malformed due date; show the validation message.
4. Update an issue to **In Progress**, then **Resolved**.
5. Show the dashboard metrics and overdue warnings.
6. Close and relaunch; show that the issue is still present.
7. Generate the Markdown, TXT and CSV reports.

## Project structure

```text
public_facility_issue_tracker/
├── app.py
├── run_gui.py
├── run_cli.py
├── seed_demo.py
├── issue_tracker/
│   ├── models.py
│   ├── storage.py
│   ├── service.py
│   ├── cli.py
│   └── gui.py
├── data/
│   ├── issues.json
│   ├── issues.csv
│   ├── sample_issues.json
│   └── sample_issues.csv
├── reports/
├── tests/
│   └── test_tracker.py
└── README.md
```

## Notes

- The project intentionally uses Python's standard library for zero-dependency execution.
- `data/issues.json` is the source of truth; `data/issues.csv` is regenerated after every successful change.
- If the JSON file is malformed, the application preserves it as `issues.corrupt.json` when possible and initializes a clean store rather than crashing.
