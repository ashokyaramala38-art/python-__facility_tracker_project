from pathlib import Path
from issue_tracker.storage import Storage
from issue_tracker.service import IssueService
from issue_tracker.gui import run_gui
if __name__ == "__main__": run_gui()
