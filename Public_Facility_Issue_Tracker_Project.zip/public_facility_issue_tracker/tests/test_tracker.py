
import tempfile, unittest
from pathlib import Path
from datetime import date, timedelta
from issue_tracker.storage import Storage
from issue_tracker.service import IssueService

class TrackerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.service=IssueService(Storage(Path(self.tmp.name)))
    def tearDown(self): self.tmp.cleanup()
    def add(self, **overrides):
        data=dict(title="Broken streetlight",description="Lamp is not working",
            category="Electricity & Lighting",location="Main road",priority="High",
            reported_by="Demo user",due_date=(date.today()+timedelta(days=2)).isoformat())
        data.update(overrides); return self.service.add(**data)
    def test_add_persists(self):
        issue=self.add()
        loaded=IssueService(Storage(Path(self.tmp.name)))
        self.assertEqual(loaded.get(issue.id).title,issue.title)
    def test_validation_rejects_blank_title(self):
        with self.assertRaises(ValueError): self.add(title=" ")
    def test_status_update_and_summary(self):
        issue=self.add(); self.service.update_status(issue.id,"Resolved")
        self.assertEqual(self.service.summary()["resolved"],1)
    def test_search_filters(self):
        self.add()
        self.assertEqual(len(self.service.search("streetlight",category="Electricity & Lighting")),1)
        self.assertEqual(len(self.service.search("unknown")),0)
    def test_overdue_detection(self):
        self.add(reported_date=(date.today()-timedelta(days=3)).isoformat(), due_date=(date.today()-timedelta(days=1)).isoformat())
        self.assertEqual(len(self.service.overdue()),1)

if __name__=="__main__": unittest.main()
