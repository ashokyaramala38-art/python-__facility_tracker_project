
"""Application use-cases, filtering, analytics, warnings and exports."""
from collections import Counter
from datetime import date, datetime
from pathlib import Path
from .models import Issue, STATUSES

class IssueService:
    def __init__(self, storage):
        self.storage = storage
        self.issues, self.load_errors = storage.load()

    def _commit(self):
        self.storage.save(self.issues)

    def add(self, **kwargs):
        issue = Issue.create(**kwargs)
        self.issues.append(issue)
        self._commit()
        return issue

    def update_status(self, issue_id, status):
        if status not in STATUSES: raise ValueError("Invalid status.")
        issue = self.get(issue_id)
        issue.status = status
        issue.updated_at = datetime.now().isoformat(timespec="seconds")
        self._commit()
        return issue

    def get(self, issue_id):
        for issue in self.issues:
            if issue.id == issue_id: return issue
        raise ValueError("Issue ID was not found.")

    def search(self, keyword="", category="All", status="All", priority="All"):
        key = keyword.casefold().strip()
        result = self.issues
        if key:
            result = [i for i in result if key in " ".join(
                [i.id, i.title, i.description, i.location, i.reported_by]).casefold()]
        if category != "All": result = [i for i in result if i.category == category]
        if status != "All": result = [i for i in result if i.status == status]
        if priority != "All": result = [i for i in result if i.priority == priority]
        return sorted(result, key=lambda i: (i.reported_date, i.id), reverse=True)

    def overdue(self):
        today = date.today()
        return [i for i in self.issues if i.status not in ("Resolved", "Closed")
                and date.fromisoformat(i.due_date) < today]

    def summary(self):
        total = len(self.issues)
        statuses = Counter(i.status for i in self.issues)
        priorities = Counter(i.priority for i in self.issues)
        categories = Counter(i.category for i in self.issues)
        resolved = statuses["Resolved"] + statuses["Closed"]
        age_days = [(date.today() - date.fromisoformat(i.reported_date)).days for i in self.issues]
        return {"total": total, "open": statuses["Open"], "in_progress": statuses["In Progress"],
                "resolved": resolved, "overdue": len(self.overdue()),
                "resolution_rate": round(resolved / total * 100, 1) if total else 0.0,
                "average_age_days": round(sum(age_days) / len(age_days), 1) if age_days else 0.0,
                "statuses": dict(statuses), "priorities": dict(priorities), "categories": dict(categories)}

    def export_report(self, reports_dir):
        folder = Path(reports_dir); folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        s = self.summary()
        lines = ["# Public Facility Issue Tracker — Executive Summary", "",
                 f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}", "",
                 "## Key metrics", f"- Total issues: {s['total']}", f"- Open: {s['open']}",
                 f"- In progress: {s['in_progress']}", f"- Resolved / closed: {s['resolved']}",
                 f"- Overdue: {s['overdue']}", f"- Resolution rate: {s['resolution_rate']}%",
                 f"- Average age: {s['average_age_days']} days", "", "## By category"]
        lines += [f"- {k}: {v}" for k, v in sorted(s["categories"].items())] or ["- No records"]
        lines += ["", "## Overdue issues"]
        lines += [f"- {i.id} | {i.title} | Due {i.due_date} | {i.priority}" for i in self.overdue()] or ["- None"]
        md = folder / f"executive_summary_{stamp}.md"
        txt = folder / f"audit_log_{stamp}.txt"
        csv_path = folder / f"issues_report_{stamp}.csv"
        md.write_text("\n".join(lines) + "\n", encoding="utf-8")
        txt.write_text("\n".join([f"{datetime.now().isoformat(timespec='seconds')} | {i.id} | {i.status} | {i.title}" for i in self.issues]) + "\n", encoding="utf-8")
        self.storage.export_csv(self.issues, csv_path)
        return md, txt, csv_path

    def import_csv(self, path):
        records, errors = self.storage.import_csv(path)
        existing = {i.id for i in self.issues}
        unique = [i for i in records if i.id not in existing]
        duplicates = len(records) - len(unique)
        self.issues.extend(unique)
        self._commit()
        if duplicates: errors.append(f"{duplicates} duplicate ID row(s) skipped.")
        return len(unique), errors
