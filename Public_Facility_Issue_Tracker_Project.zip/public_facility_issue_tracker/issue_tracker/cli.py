
"""Menu-driven terminal interface."""
from datetime import date, timedelta
from .models import CATEGORIES, PRIORITIES, STATUSES

def ask(prompt, required=True):
    while True:
        value = input(prompt).strip()
        if value or not required: return value
        print("  This field is required. Please try again.")

def choose(prompt, options):
    while True:
        print("  " + " | ".join(f"{n+1}. {v}" for n, v in enumerate(options)))
        value = input(prompt).strip()
        if value.isdigit() and 1 <= int(value) <= len(options): return options[int(value)-1]
        print("  Enter one of the listed numbers.")

def run_cli(service=None):
    if service is None:
        from pathlib import Path
        from .storage import Storage
        from .service import IssueService
        service = IssueService(Storage(Path(__file__).resolve().parents[1] / "data"))
    while True:
        print("\n" + "="*62 + "\n  PUBLIC FACILITY ISSUE TRACKER\n" + "="*62)
        print("  1. Report a new issue\n  2. View / search issues\n  3. Update issue status")
        print("  4. Executive summary\n  5. Export reports\n  6. Import legacy CSV\n  0. Exit")
        choice = input("\n  Select: ").strip()
        try:
            if choice == "1":
                title = ask("Title: "); description = ask("Description: ")
                category = choose("Category number: ", CATEGORIES)
                location = ask("Facility / location: ")
                priority = choose("Priority number: ", PRIORITIES)
                reporter = ask("Reported by: ")
                due = ask(f"Due date [YYYY-MM-DD, default {(date.today()+timedelta(days=7)).isoformat()}]: ", False)
                issue = service.add(title=title, description=description, category=category,
                    location=location, priority=priority, reported_by=reporter,
                    due_date=due or (date.today()+timedelta(days=7)).isoformat())
                print(f"  Saved successfully. Issue ID: {issue.id}")
            elif choice == "2":
                key = ask("Keyword (blank for all): ", False)
                rows = service.search(key)
                print(f"\n  Found {len(rows)} issue(s)")
                for i in rows:
                    print(f"  {i.id:8} | {i.status:11} | {i.priority:8} | {i.title[:28]:28} | {i.location[:18]}")
            elif choice == "3":
                iid = ask("Issue ID: ").upper()
                status = choose("New status number: ", STATUSES)
                print(f"  Updated: {service.update_status(iid, status).id}")
            elif choice == "4":
                s = service.summary()
                for k in ("total","open","in_progress","resolved","overdue","resolution_rate","average_age_days"):
                    print(f"  {k.replace('_',' ').title():22}: {s[k]}")
                print("  By category:", s["categories"])
                if s["overdue"]: print("  WARNING: overdue issues need attention.")
            elif choice == "5":
                print("  Created:\n  " + "\n  ".join(map(str, service.export_report(service.storage.data_dir.parent/"reports"))))
            elif choice == "6":
                path = ask("CSV file path: ")
                count, errors = service.import_csv(path)
                print(f"  Imported {count} row(s).")
                for e in errors: print("  -", e)
            elif choice == "0":
                print("  Your records are saved. Goodbye."); return
            else: print("  Choose a valid menu option.")
        except (ValueError, OSError) as exc:
            print("  Could not complete action:", exc)
