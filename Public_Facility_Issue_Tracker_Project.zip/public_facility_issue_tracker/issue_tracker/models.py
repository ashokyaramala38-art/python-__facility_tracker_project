
"""Domain model and validation for facility issues."""
from dataclasses import dataclass, asdict
from datetime import date, datetime
import re
import uuid

CATEGORIES = ["Roads & Footpaths", "Water & Plumbing", "Electricity & Lighting",
              "Cleanliness", "Parks & Recreation", "Public Buildings", "Accessibility", "Other"]
PRIORITIES = ["Low", "Medium", "High", "Critical"]
STATUSES = ["Open", "In Progress", "Resolved", "Closed"]

def clean_text(value, field, max_len=180):
    value = str(value or "").strip()
    if not value:
        raise ValueError(f"{field} cannot be blank.")
    if len(value) > max_len:
        raise ValueError(f"{field} must be {max_len} characters or fewer.")
    if any(ord(ch) < 32 and ch not in "\t" for ch in value):
        raise ValueError(f"{field} contains unsupported control characters.")
    return value

def validate_date(value, field="Date"):
    try:
        parsed = date.fromisoformat(str(value).strip())
    except (TypeError, ValueError):
        raise ValueError(f"{field} must use YYYY-MM-DD format.")
    return parsed.isoformat()

@dataclass
class Issue:
    id: str
    title: str
    description: str
    category: str
    location: str
    priority: str
    status: str
    reported_by: str
    reported_date: str
    due_date: str
    updated_at: str

    @classmethod
    def create(cls, title, description, category, location, priority,
               reported_by, due_date, reported_date=None):
        today = date.today().isoformat()
        reported = validate_date(reported_date or today, "Reported date")
        due = validate_date(due_date, "Due date")
        if category not in CATEGORIES: raise ValueError("Choose a valid category.")
        if priority not in PRIORITIES: raise ValueError("Choose a valid priority.")
        if date.fromisoformat(due) < date.fromisoformat(reported):
            raise ValueError("Due date cannot be earlier than the reported date.")
        return cls(str(uuid.uuid4())[:8].upper(),
                   clean_text(title, "Title", 100),
                   clean_text(description, "Description", 1000),
                   category, clean_text(location, "Location", 160),
                   priority, "Open", clean_text(reported_by, "Reporter", 80),
                   reported, due, datetime.now().isoformat(timespec="seconds"))

    @classmethod
    def from_dict(cls, row):
        required = {f.name for f in __import__("dataclasses").fields(cls)}
        if not required.issubset(row):
            raise ValueError("Record is missing required fields.")
        obj = cls(**{k: str(row[k]) for k in required})
        if obj.status not in STATUSES or obj.priority not in PRIORITIES or obj.category not in CATEGORIES:
            raise ValueError("Record contains an unknown category, priority, or status.")
        validate_date(obj.reported_date, "Reported date")
        validate_date(obj.due_date, "Due date")
        return obj

    def to_dict(self):
        return asdict(self)
