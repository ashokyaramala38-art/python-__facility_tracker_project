
"""Polished Tkinter desktop interface; standard-library only."""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import date, timedelta
from pathlib import Path
from .models import CATEGORIES, PRIORITIES, STATUSES
from .storage import Storage
from .service import IssueService

BG = "#F3F6FB"; NAVY = "#15243A"; BLUE = "#315EFb"; MUTED = "#6B7890"
def run_gui():
    root = tk.Tk()
    root.title("Public Facility Issue Tracker")
    root.geometry("1180x760")
    root.minsize(980, 650)
    service = IssueService(Storage(Path(__file__).resolve().parents[1] / "data"))
    root.configure(bg=BG)
    style = ttk.Style(root); style.theme_use("clam")
    style.configure("TFrame", background=BG)
    style.configure("TLabel", background=BG, foreground=NAVY, font=("Segoe UI", 10))
    style.configure("Title.TLabel", font=("Segoe UI", 22, "bold"), foreground=NAVY)
    style.configure("Sub.TLabel", foreground=MUTED, font=("Segoe UI", 10))
    style.configure("TButton", font=("Segoe UI", 10), padding=(12, 8))
    style.configure("Accent.TButton", background=BLUE, foreground="white")
    style.map("Accent.TButton", background=[("active", "#2448D8")])
    style.configure("Treeview", rowheight=30, font=("Segoe UI", 9), background="white", fieldbackground="white")
    style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#E8EDF6", foreground=NAVY)
    shell = ttk.Frame(root, padding=22); shell.pack(fill="both", expand=True)
    header = ttk.Frame(shell); header.pack(fill="x", pady=(0,18))
    ttk.Label(header, text="FACILITYCARE", font=("Segoe UI", 10, "bold"), foreground=BLUE).pack(anchor="w")
    ttk.Label(header, text="Public Facility Issue Tracker", style="Title.TLabel").pack(anchor="w", pady=(3,2))
    ttk.Label(header, text="A clear, accountable workspace for reporting and resolving community facility issues.", style="Sub.TLabel").pack(anchor="w")
    tabs = ttk.Notebook(shell); tabs.pack(fill="both", expand=True)
    dashboard = ttk.Frame(tabs, padding=16); issues_tab = ttk.Frame(tabs, padding=16); report_tab = ttk.Frame(tabs, padding=16)
    tabs.add(dashboard, text="  Overview  "); tabs.add(issues_tab, text="  Issue register  "); tabs.add(report_tab, text="  Reports & tools  ")
    cards = ttk.Frame(dashboard); cards.pack(fill="x", pady=(0,18))
    metric_vars = {}
    for label in ["Total issues","Open","In progress","Resolved / closed","Overdue","Resolution rate"]:
        card = tk.Frame(cards, bg="white", highlightbackground="#E1E7F0", highlightthickness=1, padx=15, pady=13)
        card.pack(side="left", fill="both", expand=True, padx=(0,9))
        tk.Label(card, text=label.upper(), bg="white", fg=MUTED, font=("Segoe UI",8,"bold")).pack(anchor="w")
        var = tk.StringVar(value="0"); metric_vars[label] = var
        tk.Label(card, textvariable=var, bg="white", fg=NAVY, font=("Segoe UI",21,"bold")).pack(anchor="w", pady=(7,0))
    lower = ttk.Frame(dashboard); lower.pack(fill="both", expand=True)
    left = ttk.LabelFrame(lower, text="  Status breakdown  ", padding=14); left.pack(side="left", fill="both", expand=True, padx=(0,10))
    status_text = tk.StringVar(); ttk.Label(left, textvariable=status_text, justify="left", font=("Consolas",11)).pack(anchor="nw", pady=8)
    right = ttk.LabelFrame(lower, text="  Attention required  ", padding=14); right.pack(side="left", fill="both", expand=True)
    overdue_text = tk.StringVar(); ttk.Label(right, textvariable=overdue_text, justify="left", wraplength=400).pack(anchor="nw", pady=8)
    toolbar = ttk.Frame(issues_tab); toolbar.pack(fill="x", pady=(0,12))
    keyword = tk.StringVar(); category = tk.StringVar(value="All"); status = tk.StringVar(value="All")
    ttk.Label(toolbar,text="Search").pack(side="left")
    search_entry = ttk.Entry(toolbar,textvariable=keyword,width=24); search_entry.pack(side="left", padx=7)
    ttk.Label(toolbar,text="Category").pack(side="left",padx=(10,3))
    ttk.Combobox(toolbar,textvariable=category,values=["All"]+CATEGORIES,state="readonly",width=22).pack(side="left")
    ttk.Label(toolbar,text="Status").pack(side="left",padx=(10,3))
    ttk.Combobox(toolbar,textvariable=status,values=["All"]+STATUSES,state="readonly",width=14).pack(side="left")
    cols=("id","title","category","location","priority","status","due_date")
    tree=ttk.Treeview(issues_tab,columns=cols,show="headings")
    for col,width in zip(cols,[82,210,160,160,85,105,100]):
        tree.heading(col,text=col.replace("_"," ").title()); tree.column(col,width=width,anchor="w")
    tree.pack(fill="both",expand=True)
    tree.tag_configure("overdue",foreground="#C2413B")
    actions=ttk.Frame(issues_tab); actions.pack(fill="x",pady=(12,0))
    def refresh():
        rows=service.search(keyword.get(),category.get(),status.get())
        tree.delete(*tree.get_children())
        overdue_ids={i.id for i in service.overdue()}
        for i in rows:
            tree.insert("", "end", iid=i.id, values=(i.id,i.title,i.category,i.location,i.priority,i.status,i.due_date),
                        tags=("overdue",) if i.id in overdue_ids else ())
        s=service.summary()
        vals={"Total issues":s["total"],"Open":s["open"],"In progress":s["in_progress"],
              "Resolved / closed":s["resolved"],"Overdue":s["overdue"],"Resolution rate":f'{s["resolution_rate"]}%'}
        for k,v in vals.items(): metric_vars[k].set(str(v))
        status_text.set("\n".join(f"{k:<15} {v:>4}" for k,v in s["statuses"].items()) or "No issues recorded yet.")
        overdue=service.overdue()
        overdue_text.set("\n".join(f"⚠ {i.id}  {i.title[:30]}  (due {i.due_date})" for i in overdue[:8]) if overdue else "✓ No overdue issues. Everything is on track.")
    def add_dialog():
        win=tk.Toplevel(root); win.title("Report a facility issue"); win.configure(bg=BG); win.transient(root); win.grab_set()
        frm=ttk.Frame(win,padding=20); frm.pack(fill="both",expand=True)
        entries={}
        fields=[("Title",""),("Description",""),("Facility / location",""),("Reported by","")]
        for r,(label,_) in enumerate(fields):
            ttk.Label(frm,text=label).grid(row=r,column=0,sticky="w",pady=6)
            e=ttk.Entry(frm,width=48); e.grid(row=r,column=1,sticky="ew",pady=6); entries[label]=e
        for r,(label,values,default) in enumerate([
            ("Category",CATEGORIES,CATEGORIES[0]),("Priority",PRIORITIES,"Medium")],start=4):
            ttk.Label(frm,text=label).grid(row=r,column=0,sticky="w",pady=6)
            v=tk.StringVar(value=default); ttk.Combobox(frm,textvariable=v,values=values,state="readonly",width=45).grid(row=r,column=1,sticky="ew",pady=6); entries[label]=v
        ttk.Label(frm,text="Due date (YYYY-MM-DD)").grid(row=6,column=0,sticky="w",pady=6)
        due=tk.StringVar(value=(date.today()+timedelta(days=7)).isoformat()); ttk.Entry(frm,textvariable=due,width=48).grid(row=6,column=1,sticky="ew",pady=6)
        def save():
            try:
                i=service.add(title=entries["Title"].get(),description=entries["Description"].get(),
                    category=entries["Category"].get(),location=entries["Facility / location"].get(),
                    priority=entries["Priority"].get(),reported_by=entries["Reported by"].get(),due_date=due.get())
                win.destroy(); refresh(); messagebox.showinfo("Issue recorded",f"Issue {i.id} was saved.",parent=root)
            except ValueError as exc: messagebox.showerror("Check your entry",str(exc),parent=win)
        ttk.Button(frm,text="Save issue",style="Accent.TButton",command=save).grid(row=7,column=1,sticky="e",pady=14)
        frm.columnconfigure(1,weight=1)
    def update_dialog():
        sel=tree.selection()
        if not sel: messagebox.showwarning("Select an issue","Choose an issue from the register first."); return
        iid=sel[0]; win=tk.Toplevel(root); win.title("Update issue status")
        ttk.Label(win,text=f"Update status for {iid}",padding=16).pack()
        val=tk.StringVar(value=service.get(iid).status)
        ttk.Combobox(win,textvariable=val,values=STATUSES,state="readonly",width=22).pack(padx=16,pady=8)
        def save():
            try: service.update_status(iid,val.get()); win.destroy(); refresh()
            except ValueError as exc: messagebox.showerror("Update failed",str(exc))
        ttk.Button(win,text="Save status",command=save).pack(pady=12)
    ttk.Button(actions,text="+ Report issue",style="Accent.TButton",command=add_dialog).pack(side="left")
    ttk.Button(actions,text="Update selected status",command=update_dialog).pack(side="left",padx=8)
    ttk.Button(actions,text="Refresh",command=refresh).pack(side="right")
    keyword.trace_add("write",lambda *_:refresh()); category.trace_add("write",lambda *_:refresh()); status.trace_add("write",lambda *_:refresh())
    ttk.Label(report_tab,text="Reports & data management",style="Title.TLabel").pack(anchor="w",pady=(0,5))
    ttk.Label(report_tab,text="Export a timestamped executive summary, audit log and CSV snapshot. Import legacy CSV files with row-level validation.",style="Sub.TLabel",wraplength=900).pack(anchor="w",pady=(0,20))
    def export():
        paths=service.export_report(service.storage.data_dir.parent/"reports")
        messagebox.showinfo("Reports exported","Created:\n"+"\n".join(str(p) for p in paths),parent=root)
    def import_file():
        path=filedialog.askopenfilename(filetypes=[("CSV files","*.csv"),("All files","*.*")])
        if not path:return
        try:
            count,errors=service.import_csv(path); refresh()
            messagebox.showinfo("Import complete",f"Imported: {count}\nRejected / skipped: {len(errors)}\n\n"+"\n".join(errors[:12]),parent=root)
        except OSError as exc: messagebox.showerror("Import failed",str(exc),parent=root)
    ttk.Button(report_tab,text="Generate reports",style="Accent.TButton",command=export).pack(anchor="w",pady=7)
    ttk.Button(report_tab,text="Import legacy CSV",command=import_file).pack(anchor="w",pady=7)
    ttk.Label(report_tab,text=f"Data folder: {service.storage.data_dir}",style="Sub.TLabel").pack(anchor="w",pady=(22,5))
    ttk.Label(report_tab,text="Tip: records are saved locally to data/issues.json and data/issues.csv whenever you make a change.",style="Sub.TLabel").pack(anchor="w")
    refresh()
    if service.load_errors: messagebox.showwarning("Storage notice","\n".join(service.load_errors),parent=root)
    root.mainloop()
