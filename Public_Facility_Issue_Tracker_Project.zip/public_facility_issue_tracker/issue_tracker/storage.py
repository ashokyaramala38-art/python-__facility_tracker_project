
"""Safe local JSON/CSV persistence."""
import csv, json
from pathlib import Path
from .models import Issue

FIELDS = ["id", "title", "description", "category", "location", "priority",
          "status", "reported_by", "reported_date", "due_date", "updated_at"]

class Storage:
    def __init__(self, data_dir):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "issues.json"
        self.csv_path = self.data_dir / "issues.csv"
        self.ensure_files()

    def ensure_files(self):
        if not self.json_path.exists():
            self.save([])
        if not self.csv_path.exists():
            self.export_csv([])

    def load(self):
        try:
            raw = json.loads(self.json_path.read_text(encoding="utf-8"))
            if not isinstance(raw, list): raise ValueError("JSON root must be a list.")
            records, errors = [], []
            for index, row in enumerate(raw, 1):
                try: records.append(Issue.from_dict(row))
                except Exception as exc: errors.append(f"Record {index}: {exc}")
            return records, errors
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            backup = self.json_path.with_suffix(".corrupt.json")
            try: self.json_path.replace(backup)
            except OSError: pass
            self.save([])
            return [], [f"Storage was unreadable and a fresh file was created: {exc}"]

    def save(self, issues):
        temp = self.json_path.with_suffix(".tmp")
        temp.write_text(json.dumps([i.to_dict() for i in issues], indent=2, ensure_ascii=False), encoding="utf-8")
        temp.replace(self.json_path)
        self.export_csv(issues)

    def export_csv(self, issues, path=None):
        target = Path(path) if path else self.csv_path
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.DictWriter(handle, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(i.to_dict() for i in issues)

    def import_csv(self, path):
        imported, errors = [], []
        with open(path, newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            missing = set(FIELDS) - set(reader.fieldnames or [])
            if missing: return [], [f"Missing columns: {', '.join(sorted(missing))}"]
            for line, row in enumerate(reader, 2):
                try:
                    imported.append(Issue.from_dict(row))
                except Exception as exc:
                    errors.append(f"Row {line}: {exc}")
        return imported, errors
